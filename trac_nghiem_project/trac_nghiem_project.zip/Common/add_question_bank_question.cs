﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace trac_nghiem_project.Common
{
    public class AddQuestion
    {
        public long id_question_bank { get; set; }
        
    }
}