﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace trac_nghiem_project.Common
{
    public class DetailDoExam
    {
        public string chose { get; set; }
        public string correct { get; set; }
        public int status { get; set; }
    }
}